/* ========================== typing nimation ========================== */
/*var typed = new Typed(".typing",{
    strings:["","සඵලත්වයේ සිංහල පන්තිය","සඵලත්වයේ සිංහල පන්තිය","සඵලත්වයේ සිංහල පන්තිය"],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
})*/